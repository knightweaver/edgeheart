# Edgeheart Extraction & Foundry Integration — Chat Handoff Summary

## Purpose and architecture

This thread extracted reusable mechanics from the uploaded **Edgeheart - The Homebrewery** PDF for the **Cybermancy - System** project.

Edgeheart is an external source/reference. It does **not** override current canonical Cybermancy rules.

The user approved this pipeline:

```text
Edgeheart PDF
→ neutral Edgeheart JSON
→ source/schema validation
→ deterministic Edgeheart → Foundry compiler
→ Foundry JSON / dependency bundles
→ runtime import + semantic verification
```

Do not bypass the neutral layer. Do not rebalance, rename, modernize, or silently correct source mechanics during extraction.

## Foundry target

Exact runtime directly probed/tested:

- Foundry VTT **13.351**
- Daggerheart **1.2.7**

Important: `system.actions` is an **object/dictionary keyed by action ID**, not an array.

Confirmed Daggerheart Item types include `ancestry`, `armor`, `attachableItem`, `class`, `community`, `consumable`, `domainCard`, `feature`, `loot`, `subclass`, `weapon`, and `beastform`.

## Final source scope

Included: Classes, Subclasses, Life Paths, Affiliations, Weapons, Armor, Loot, Consumables, Cyberware, Environments, Adversaries, Competencies, and Competency Cards.

Excluded as standalone entities: Eidolons and General Rules / Edgeheart Mechanics.

Strict Eidolon exclusions:
- Eidolon Deployment Zone
- Combat Eidolon Frame
- Ares-Tyrant Eidolon
- The Raven Eidolon

References to excluded Eidolons inside included records remain source-faithful.

## Final inventory — 549 entities

| Family | Count |
|---|---:|
| Weapons | 64 |
| Armor | 25 |
| Loot | 40 |
| Consumables | 40 |
| Cyberware | 60 |
| Classes | 9 |
| Subclasses | 18 |
| Life Paths | 6 |
| Affiliations | 8 |
| Competencies | 11 |
| Competency Cards | 231 |
| Environments | 15 |
| Adversaries | 22 |
| **Total** | **549** |

## Batch A — Weapons + Armor

89 entities: 64 Weapons + 25 Armor.

- neutral validation PASS 89/89
- Foundry compilation/static validation PASS 89/89
- representative runtime proof passed

Schema refinement: armor supports multiple independently named features via `features[]`.

## Batch B — Loot + Consumables + Cyberware

140 entities: 40 Loot + 40 Consumables + 60 Cyberware.

- neutral validation PASS 140/140
- static Foundry validation PASS 140/140
- representative runtime fixtures passed

Cyberware patterns include variable Cyber Cost, Competency access, embedded weapons, and charge-bearing implants.

Do **not** infer Cyberware Tier per record.

## Batch C — Classes + Subclasses + Origins

41 entities: 9 Classes + 18 Subclasses + 6 Life Paths + 8 Affiliations.

Class/Subclass:
- 9 dependency bundles compile
- Runner/Breach Specialist/Net Diver live bundle precedent passed

Preserved source naming conflicts:
- Signal Ghost vs detailed subclass **Net Diver**
- Deep Cover vs detailed subclass **Phantom**

Detailed titles are retained; alternate choice-line names remain alias/conflict metadata.

Origin mapping proven against exact runtime:
- Life Path → Daggerheart `ancestry`
- Affiliation → Daggerheart `community`

Exact structures:
- ancestry `system.features`: `{type, item}` references
- community `system.features`: Feature UUID strings
- both use `system.attribution`

All 14 origin bundles:
- pre-import PASS 14/14
- import PASS 14/14
- post-import PASS 14/14
- sheet render PASS 14/14
- user cursory review successful

## Batch D — Competencies + Competency Cards

242 entities: 11 Competencies + 231 cards.

Competencies:
Network, Assault, Chrome, Systems, Influence, Ghost, Frontier, Medtech, Aegis, Redline, Blackwall.

Each has 21 cards:
- 3 Level 1
- 2 at every Level 2–10

Cards compile as Daggerheart `domainCard` Items. Printed Edgeheart card type stays preserved in source flags.

The 11 Competencies themselves are **not fabricated as Items**. Their corresponding lowercase domain identifiers must be registered/configured in Daggerheart before final card deployment.

The Personal Firewall pilot proved the dependency: structurally valid JSON failed actual creation because `network` was not registered. The user explicitly decided this was **not** an extraction blocker.

### Batch D fidelity condition

The PDF native text layer is corrupted.

- 9 missed card blocks were manually transcribed from rendered pages
- 222 card rule bodies used OCR fallback
- names/levels/Competency/type/Recall Cost/pages/counts were visually reconciled
- those 222 remain marked `hybrid` / `transcribed`
- OCR reconciliation material is retained

Do not claim all 231 rule bodies have independent word-for-word visual double-checking.

## Batch E — Environments + Adversaries

37 entities: 15 Environments + 22 Adversaries after strict Eidolon exclusion.

Environment Tiers: 4 / 4 / 3 / 4.
Adversary Tiers: 6 / 6 / 5 / 5.

- neutral schema PASS 37/37
- semantic validation PASS
- static Foundry validation PASS 37/37
- representative runtime proof passed with Sitil Security Guard + Neon Night Market

Compiler cases:
- Neon Claw Ganger `3 phy` → custom flat Foundry damage formula `3`
- Chrome Maw Bruiser `impact` retained raw; normalized to physical for Foundry
- Chrome Reaper + Black Hand `Far or Melee` → functional single range `Far`, exact source range preserved in flags/description

Boundary: Batch E is **faithful Edgeheart source → Foundry mapping**, not canonical Cybermancy Fast Play production.

## Consolidated package

Current working artifact:

**`edgeheart-consolidated-production-v1.0.zip`**

Neutral layer:
- all 549 individual records
- consolidated schema
- `neutral/edgeheart-neutral-corpus.v1.0.json`
- schema PASS 549/549
- counts/uniqueness/distributions PASS

Foundry layer:
- **497 direct payloads**
- **9 Class/Subclass dependency bundles**
- **14 origin dependency bundles**
- Competency-domain registration manifest
- regression smoke/probe macros

The package also includes batch manifests, runtime evidence, consolidated validation, source-fidelity reports, and Batch D OCR reconciliation files.

## Precise runtime claim

Proven:
- 549 neutral records schema-valid
- 497 direct payloads parse and satisfy actions-dictionary invariant
- 9 class bundles structurally valid
- 14 origin bundles structurally valid and individually live-imported
- representative runtime vertical slices passed across remaining families

Not done:
- all 497 direct payloads have **not** each been imported one-by-one
- 11 Competency domains are not yet registered
- 222 OCR-assisted Batch D rule bodies have not all received independent visual retranscription

## Cybermancy authority boundary

This package is a working extraction output, not an authority over canonical Cybermancy mechanics.

For any later Adversary/Environment conversion to canonical Cybermancy production form, use:
- CYBERMANCY_PIPELINE_CONTRACT v1.2
- Production Standard v1.1
- Entity Spec v1.1
- Front-End Standard v1.1
- Package Builder v1.2.2
- Feature Library v1
- Fast Play v1
- Cascade Burrowtail as canonical Fast Play example

## Next task — generated replacement art

Before making art prompts, inspect the current connected `knightweaver/cybermancy` GitHub repository, especially:

- `docs/gm-facing/meta/visual-canon.md`
- `pyCybermancy/batch-image-generation-on-OpenAI.py`
- `batch-image-generation-simple-prompt-file.py` if still current
- current CSV/header expectations

Then generate a deterministic art request/CSV manifest for the extracted entities.

Do **not** copy, extract, trace, or reuse Edgeheart's source illustrations.

Known visual note: subdermal cyberware should appear integrated beneath intact skin, not as external armor, unless explicitly external.

## Suggested next-thread opening prompt

> Continue the Edgeheart extraction/integration work from the attached `edgeheart-consolidated-production-v1.0.zip` and `EDGEHEART_EXTRACTION_HANDOFF_SUMMARY.md`. Treat the consolidated package as the current working extraction output, not as a source that overrides canonical Cybermancy rules. Do not re-extract the 549 entities unless validation reveals a concrete defect. The next task is generated replacement art: inspect the current `knightweaver/cybermancy` repository's visual canon and image-generation scripts, then design a deterministic art-prompt/CSV manifest for the extracted Edgeheart entities. Preserve the documented Batch D source-fidelity condition and the Competency-domain registration dependency.
