# Edgeheart Consolidated Source Corpus & Foundry Production Package v1.0

This is the consolidated working extraction artifact for **Cybermancy - System**.

- Neutral source records: **549/549 schema-valid**
- Direct Foundry payloads: **497**
- Class/Subclass dependency bundles: **9**
- Origin dependency bundles: **14**
- Competency/domain registrations still required: **11**

See `validation/CONSOLIDATED_VALIDATION_REPORT.json`, `validation/RUNTIME_QUALIFICATION_MATRIX.md`, and `foundry/IMPORT_GUIDE.md`.

Important qualifications:
- 222 Batch D card rule bodies remain OCR-assisted and are explicitly marked `hybrid` / `transcribed`.
- Batch E Environments/Adversaries are source-faithful mappings, not Cybermancy Fast Play entities.
- The 11 Competencies must be registered as Daggerheart domains before all 231 cards can be finally deployed.
