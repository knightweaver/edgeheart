# Edgeheart Production Extraction — Batch B v0.1

Batch B contains **140 source entities** from Edgeheart v1.1:

- 40 Loot (pp. 37–38)
- 40 Consumables (pp. 39–40)
- 60 Cyberware (pp. 42–44; p. 41 supplies Cyberware/Competency Access context)

## Validation status

- Neutral JSON Schema: **PASS — 140/140**
- Semantic roll/count checks: **PASS**
- Static Foundry payload validation: **PASS — 140/140**
- Runtime transformation precedent: **PASS** from the accepted v0.2 Foundry vertical-slice tests for Loot, Consumable, simple Cyberware, Competency-access Cyberware, and weapon-like Cyberware.

A full-batch Foundry import is optional regression testing rather than a family-authorization blocker.

## Source fidelity

Cyberware Tier is not inferred per record: page 41 describes Tier semantics, but the individual list prints Roll, Cyberware, Cost, and Feature only. Apparent source typos/awkward phrases are retained and listed in `reports/source-fidelity-notes.json`.
