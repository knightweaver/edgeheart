# Edgeheart Production Extraction — Batch E v0.1

Batch E completes the requested Edgeheart extraction scope.

## Included

- **15 Environments** from pp. 54–57
- **22 Adversaries** from pp. 58–64
- **37 total entities**

## Strict Eidolon exclusions

The following four source entities are deliberately omitted:

- Environment: **Eidolon Deployment Zone** (p. 56)
- Adversary: **Combat Eidolon Frame** (p. 61)
- Adversary: **Ares-Tyrant Eidolon** (p. 63)
- Adversary: **The Raven Eidolon** (p. 64)

Textual references to Eidolons remain where they are part of an included source entity. No substitute entities are invented.

## Validation

- Neutral JSON Schema: **PASS — 37/37**
- Tier/count/threshold semantic checks: **PASS**
- Static Foundry validation: **PASS — 37/37**
- Runtime family precedent: **PASS** from the accepted v0.2 live Foundry tests of **Sitil Security Guard** and **Neon Night Market** on Foundry 13.351 / Daggerheart 1.2.7.

## Compiler compatibility cases

Three source patterns required explicit, non-destructive handling:

1. **Neon Claw Ganger** deals flat `3 phy` damage. The Foundry payload uses a custom damage formula of `3` rather than inventing a die expression.
2. **Chrome Reaper** and **Black Hand** use source range `Far or Melee`. Daggerheart's single attack-range field is compiled as `Far`; the exact source range is preserved in `flags.edgeheart.source.attackRangeRaw` and in the attack description.
3. **Chrome Maw Bruiser** uses `impact` damage. The raw source type remains `impact`; its Foundry normalized damage type is physical.

See `reports/compiler-special-cases.json`.

## Important boundary

This package is a **faithful Edgeheart extraction and Foundry mapping**. It does **not** redesign these entities into canonical Cybermancy adversaries/environments and does not synthesize Cybermancy Fast Play. Any later adoption into the canonical Cybermancy production pipeline is a separate design step.

## Contents

- `neutral/environments/`
- `neutral/adversaries/`
- `compiled/environments/`
- `compiled/adversaries/`
- `reports/`
- `schemas/`
- `src/`
- aggregate neutral corpus and manifest
