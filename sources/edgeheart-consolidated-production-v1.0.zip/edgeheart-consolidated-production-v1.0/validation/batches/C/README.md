# Edgeheart Production Extraction — Batch C v0.1

Batch C contains **41 source entities** from Edgeheart v1.1:

- 9 Classes (pp. 11–28)
- 18 Subclasses (pp. 11–28)
- 6 Life Paths (p. 29)
- 8 Affiliations (p. 30)

## Validation status

- Neutral JSON Schema: **PASS — 41/41**
- Alias-aware relationship checks: **PASS**
- Class/Subclass bundle compilation: **PASS — 9/9 bundles**
- Action container invariant (`system.actions` dictionary): **PASS**
- Class/Subclass runtime precedent: **PASS** from the accepted Runner/Breach Specialist/Net Diver v0.2 Foundry test.

## Preserved source conflicts

Two naming conflicts are retained rather than silently resolved:

1. Runner p.11 says **Signal Ghost**; the detailed subclass on p.12 is **Net Diver**.
2. Infiltrator p.13 says **Deep Cover**; the detailed subclass on p.14 is **Phantom**.

The detailed subclass records retain the printed detailed titles and include the choice-line names as aliases so references can resolve without erasing the conflict.

## Life Paths and Affiliations

The neutral extraction is complete. Their exact Foundry 1.2.7 field-level compiler remains intentionally blocked until we obtain a current runtime exemplar.

Current candidate type mapping:

- Life Path → Daggerheart `ancestry`
- Affiliation → Daggerheart `community`

Run `foundry/edgeheart-origin-target-probe.js` in the exact Foundry 13.351 / Daggerheart 1.2.7 runtime. It makes no changes; it exports one existing `ancestry` and `community` exemplar if available. That output will let us implement the final origin compiler without guessing.

## Contents

- `neutral/` — 41 source-faithful records
- `compiled/class-bundles/` — 9 deterministic class/subclass dependency bundles
- `foundry/edgeheart-class-bundle-smoke-test.js` — optional regression importer
- `foundry/edgeheart-origin-target-probe.js` — read-only runtime target discovery
- `reports/` — validation and target-status reports
- `src/` and `schemas/` — exact compiler/schema/validator used


## v0.2 origin compiler completion

The exact target-runtime probe confirmed:

- `lifePath` maps to Daggerheart Item type `ancestry`.
- `affiliation` maps to Daggerheart Item type `community`.
- Ancestry `system.features` is an array of `{type, item}` references.
- Community `system.features` is an array of feature Item UUID strings.
- Both use `system.attribution`.

All 14 origin bundles now compile and pass static validation. Live Foundry import remains the final gate. Use:

- `foundry/edgeheart-origin-bundle-smoke-test-v0.2.js`
- the 14 files in `compiled/origin-bundles/`


## v0.3 runtime acceptance

The complete origin runtime smoke test was executed against **Foundry VTT 13.351 / Daggerheart 1.2.7**.

Results:

- Pre-import validation: **14/14 PASS**
- Foundry import: **14/14 PASS**
- Post-import semantic checks: **14/14 PASS**
- Sheet rendering: **14/14 PASS**
- User cursory visual review: **PASS**

This closes the remaining Batch C runtime gate. Batch C is now fully runtime-qualified.
