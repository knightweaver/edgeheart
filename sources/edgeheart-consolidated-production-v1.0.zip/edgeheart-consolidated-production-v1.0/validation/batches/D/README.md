# Edgeheart Production Extraction — Batch D v0.1

Batch D contains **242 source entities**:

- **11 Competencies** from pp. 65–66
- **231 Competency Cards** from pp. 67–89
- exactly **21 cards per Competency**

## Validation

- Neutral JSON Schema: **PASS — 242/242**
- Card count / level distribution: **PASS**
- Unique card names/slugs: **PASS**
- Deterministic Foundry `domainCard` compilation: **PASS — 231/231**
- Static Foundry validation: **PASS — 231/231**

Every Competency has three Level 1 cards and two cards at each level from 2 through 10.

## Foundry deployment boundary

The cards compile as Daggerheart `domainCard` Items. Their source Competency is preserved in neutral JSON and in `flags.edgeheart.source`, while `system.domain` uses the corresponding lowercase domain identifier.

The 11 Competencies themselves are **not fabricated as Item documents**. Final deployment requires those identifiers to be registered/configured as domains in the target Daggerheart installation. This is the same external dependency exposed by the earlier Personal Firewall test and is not treated as an extraction blocker.

See `deployment/competency-domain-manifest.v0.1.json`.

## Source fidelity note

The Edgeheart PDF text layer is corrupted. Card rule text therefore required a batched OCR fallback. Card names, levels, types, recall costs, page placement, counts, and OCR exceptions were reconciled against the rendered pages.

Nine card blocks that OCR segmentation missed were manually transcribed from the rendered source.

The remaining OCR-assisted rule bodies are marked `hybrid` / `transcribed` in neutral JSON rather than falsely claiming an independent word-for-word second transcription. The raw OCR reconciliation text is included under `source-reconciliation/` so a future line-level fidelity sweep is reproducible.

No mechanics were rebalanced or translated during extraction.

## Contents

- `neutral/competencies/` — 11 neutral Competency records
- `neutral/competency-cards/` — 231 neutral cards by Competency and Level
- `compiled/domain-cards/` — 231 deterministic Foundry candidates
- `deployment/` — domain dependency/registration manifest
- `reports/` — source-fidelity, distribution, and static-validation reports
- `source-reconciliation/` — OCR fallback text retained for audit
- `schemas/` and `src/` — exact schema/compiler/validator used
