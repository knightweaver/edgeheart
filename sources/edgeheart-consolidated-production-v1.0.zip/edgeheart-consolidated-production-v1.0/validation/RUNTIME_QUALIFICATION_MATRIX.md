# Edgeheart Foundry Runtime Qualification Matrix

Target runtime: **Foundry VTT 13.351 / Daggerheart 1.2.7**

| Family | Static validation | Runtime qualification |
|---|---|---|
| Weapons | PASS 64/64 | Representative Assault Carbine live vertical slice PASS |
| Armor | PASS 25/25 | Representative v0.2 live fixtures PASS |
| Loot | PASS 40/40 | Representative v0.2 live fixture PASS |
| Consumables | PASS 40/40 | Representative v0.2 live fixture PASS |
| Cyberware | PASS 60/60 | Simple, Competency-access, and embedded-weapon representatives PASS |
| Classes/Subclasses | PASS 9/9 bundles | Runner/Breach Specialist/Net Diver live bundle precedent PASS |
| Life Paths/Affiliations | PASS 14/14 bundles | **14/14 live import + post-import + sheet-render PASS** |
| Competency Cards | PASS 231/231 | Conditional on registering corresponding Daggerheart domain IDs |
| Competencies | PASS neutral/deployment manifest | Domain registration required; no invented Item type |
| Environments/Adversaries | PASS 37/37 | Sitil Security Guard + Neon Night Market live precedent PASS |

This does not claim that all 497 direct payloads were individually imported. The project used full deterministic/static validation plus representative family-level runtime vertical slices.
