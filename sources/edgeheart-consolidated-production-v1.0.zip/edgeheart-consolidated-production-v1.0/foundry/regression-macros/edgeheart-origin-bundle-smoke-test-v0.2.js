/**
 * Edgeheart Origin Bundle Smoke Test v0.2
 * Target: Foundry VTT 13.351 / Daggerheart 1.2.7
 * Supports Edgeheart Life Path->ancestry and Affiliation->community bundles.
 * Never deletes existing content.
 */
(async () => {
  const TARGET_CORE="13.351", TARGET_SYSTEM="1.2.7";
  const isObj=v=>v&&typeof v==="object"&&!Array.isArray(v);
  const validateActions=(actions,ctx,errors)=>{
    if(actions===undefined)return;
    if(!isObj(actions)){errors.push(`${ctx}.actions MUST be object/dictionary`);return;}
    for(const [id,a] of Object.entries(actions)){
      if(!isObj(a)){errors.push(`${ctx}.actions.${id} not object`);continue;}
      if(a._id!==id)errors.push(`${ctx}.actions.${id} _id mismatch`);
      if(a.systemPath!=="actions")errors.push(`${ctx}.actions.${id} systemPath mismatch`);
    }
  };
  async function ensureFolderPath(names,type='Item'){
    let parentId=null,folder=null;
    for(const name of names){
      folder=game.folders.find(f=>f.type===type&&f.name===name&&(f.parent?.id??null)===parentId)??null;
      if(!folder)folder=await Folder.create({name,type,parent:parentId});
      parentId=folder.id;
    }
    return folder;
  }
  function sanitize(data){
    const d=foundry.utils.deepClone(data);
    for(const k of ['_stats','_key','ownership','folder','_id','sort']) delete d[k];
    return d;
  }
  async function createItem(doc,folder){
    const d=sanitize(doc); d.folder=folder?.id??null;
    return await Item.create(d,{renderSheet:false});
  }
  function preflight(doc){
    const errors=[];
    if(!isObj(doc))errors.push("root must be object");
    if(typeof doc?.name!=="string")errors.push("name required");
    if(typeof doc?.type!=="string")errors.push("type required");
    if(!isObj(doc?.system))errors.push("system object required");
    validateActions(doc?.system?.actions,doc?.type??"doc",errors);
    return {status:errors.length?"fail":"pass",errors};
  }
  const content=`<form>
    <div class="form-group"><label>Origin bundle JSON files</label>
    <input type="file" name="files" accept=".json,application/json" multiple /></div>
    <div class="form-group"><label class="checkbox">
    <input type="checkbox" name="renderSheets" checked /> Render imported origin sheets</label></div>
    <p>No automatic cleanup. Imported fixtures remain in Edgeheart Validation / Origin Bundles.</p>
  </form>`;
  const choice=await new Promise(resolve=>new Dialog({
    title:"Edgeheart Origin Bundle Smoke Test v0.2",content,
    buttons:{
      run:{label:"Import & Test",callback:html=>resolve({
        files:Array.from(html.find('input[name="files"]')[0].files??[]),
        renderSheets:html.find('input[name="renderSheets"]')[0].checked
      })},
      cancel:{label:"Cancel",callback:()=>resolve(null)}
    },default:"run"
  }).render(true));
  if(!choice||!choice.files.length)return;

  const runtime={
    foundryCore:String(game.version??""),
    systemId:String(game.system?.id??""),
    systemVersion:String(game.system?.version??"")
  };
  runtime.targetMatch=runtime.foundryCore===TARGET_CORE&&runtime.systemId==="daggerheart"&&runtime.systemVersion===TARGET_SYSTEM;

  const report={reportVersion:"0.2",runAt:new Date().toISOString(),runtime,fixtures:[]};

  for(const file of choice.files){
    const row={file:file.name,preImport:{status:"pass",errors:[]},import:{status:"not-run"},
      postImport:{status:"not-run",mismatches:[]},sheetRender:{attempted:false,succeeded:null,error:null},
      manualVisualInspection:"pending",created:[]};
    try{
      const bundle=JSON.parse(await file.text());
      row.fixtureId=bundle.fixtureId; row.originKind=bundle.originKind;
      if(bundle.kind!=="origin")throw new Error("Not an origin bundle");
      const lookup={};
      const folder=await ensureFolderPath(["Edgeheart Validation","Origin Bundles"],"Item");

      for(const entry of bundle.creationOrder??[]){
        const pf=preflight(entry.document);
        if(pf.status!=="pass")throw new Error(`${entry.key} preflight: ${pf.errors.join("; ")}`);
        const created=await createItem(entry.document,folder);
        if(!created)throw new Error(`${entry.key}: Item.create returned no document`);
        lookup[entry.key]=created; row.created.push({key:entry.key,uuid:created.uuid});
      }

      const pentry=bundle.parent;
      let pdoc=foundry.utils.deepClone(pentry.document);
      if(pdoc.type==="ancestry"){
        pdoc.system.features=(pdoc.system.features??[]).map(x=>({type:x.type,item:lookup[x.ref]?.uuid??x.ref}));
      } else if(pdoc.type==="community"){
        pdoc.system.features=(pdoc.system.features??[]).map(x=>lookup[x]?.uuid??x);
      } else {
        throw new Error(`Unsupported parent type ${pdoc.type}`);
      }
      const parent=await createItem(pdoc,folder);
      if(!parent)throw new Error("parent: Item.create returned no document");
      row.created.push({key:pentry.key,uuid:parent.uuid});
      row.import={status:"pass",count:row.created.length,parentUuid:parent.uuid,parentType:parent.type};

      const obj=parent.toObject();
      const mismatches=[];
      if(obj.name!==pentry.document.name)mismatches.push({path:"name",expected:pentry.document.name,actual:obj.name});
      if(obj.type!==pentry.document.type)mismatches.push({path:"type",expected:pentry.document.type,actual:obj.type});
      const gotCount=Array.isArray(obj.system?.features)?obj.system.features.length:null;
      const wantCount=Array.isArray(pentry.document.system?.features)?pentry.document.system.features.length:null;
      if(gotCount!==wantCount)mismatches.push({path:"system.features.length",expected:wantCount,actual:gotCount});
      if(obj.system?.attribution?.source!=="Edgeheart")mismatches.push({path:"system.attribution.source",expected:"Edgeheart",actual:obj.system?.attribution?.source});
      row.postImport={status:mismatches.length?"fail":"pass",mismatches};

      if(choice.renderSheets){
        row.sheetRender.attempted=true;
        try{parent.sheet.render(true);row.sheetRender.succeeded=true;}
        catch(e){row.sheetRender.succeeded=false;row.sheetRender.error=String(e);}
      }
    }catch(e){
      row.import={status:"fail",error:String(e)};
      row.runtimeError=String(e);
    }
    report.fixtures.push(row);
  }

  console.log("Edgeheart origin smoke-test report",report);
  saveDataToFile(JSON.stringify(report,null,2),"application/json",
    `edgeheart-origin-smoke-${new Date().toISOString().replace(/[:.]/g,"-")}.json`);
  const imported=report.fixtures.filter(r=>r.import?.status==="pass").length;
  const semantic=report.fixtures.filter(r=>r.postImport?.status==="pass").length;
  ui.notifications.info(`Edgeheart origin smoke test: ${imported}/${report.fixtures.length} imported; ${semantic}/${report.fixtures.length} semantic checks passed.`);
})();