/**
 * Edgeheart Origin Target Probe v0.1
 * Target runtime: Foundry VTT 13.351 / Daggerheart 1.2.7.
 *
 * Finds one existing ancestry Item and one existing community Item in world or compendia,
 * exports sanitized exemplars, and downloads a report. Makes no changes.
 */
(async () => {
  const sanitize = obj => {
    const d = foundry.utils.deepClone(obj);
    for (const k of ["_stats","_key","ownership","folder","sort"]) delete d[k];
    return d;
  };

  async function findExample(type) {
    const world = game.items.find(i => i.type === type);
    if (world) return {source:"world", pack:null, document:sanitize(world.toObject())};

    for (const pack of game.packs) {
      if (pack.documentName !== "Item") continue;
      let index;
      try { index = await pack.getIndex({fields:["type"]}); } catch { continue; }
      const hit = index.find(e => e.type === type);
      if (!hit) continue;
      try {
        const doc = await pack.getDocument(hit._id);
        if (doc) return {source:"compendium", pack:pack.collection, document:sanitize(doc.toObject())};
      } catch {}
    }
    return null;
  }

  const report = {
    reportVersion:"0.1",
    runAt:new Date().toISOString(),
    runtime:{
      foundryCore:String(game.version ?? ""),
      systemId:String(game.system?.id ?? ""),
      systemVersion:String(game.system?.version ?? "")
    },
    registeredItemTypes:Object.keys(CONFIG.Item?.dataModels ?? game.system?.documentTypes?.Item ?? {}),
    ancestry:await findExample("ancestry"),
    community:await findExample("community")
  };
  console.log("Edgeheart Origin Target Probe", report);
  saveDataToFile(JSON.stringify(report,null,2),"application/json",
    `edgeheart-origin-target-probe-${new Date().toISOString().replace(/[:.]/g,"-")}.json`);
  ui.notifications.info(`Origin probe complete: ancestry ${report.ancestry?"found":"not found"}, community ${report.community?"found":"not found"}.`);
})();
