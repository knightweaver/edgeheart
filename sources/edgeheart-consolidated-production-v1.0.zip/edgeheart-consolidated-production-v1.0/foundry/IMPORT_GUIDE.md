# Edgeheart Foundry Production Package — Import Guide

Target runtime: **Foundry VTT 13.351 / Daggerheart 1.2.7**

`foundry/direct/` contains **497** direct payloads: 64 weapons, 25 armors, 40 loot, 40 consumables, 60 cyberware Features, 231 `domainCard` Items, 15 environments, and 22 adversaries.

`foundry/bundles/classes/` contains **9** Class/Subclass dependency bundles.

`foundry/bundles/origins/` contains **14** origin bundles:
- 6 Life Paths → `ancestry`
- 8 Affiliations → `community`

All 14 origin bundles passed live import, post-import checks, and sheet rendering.

## Competency / Domain dependency

The 11 Edgeheart Competencies remain neutral source entities, not fabricated Item documents. The 231 cards compile as `domainCard` Items with lowercase Competency identifiers in `system.domain`.

Before final deployment, the corresponding domains must be registered/configured in Daggerheart. The earlier Personal Firewall pilot demonstrated that structurally valid domain-card JSON can fail creation if its domain is not registered.

See `foundry/deployment/competency-domain-manifest.v0.1.json`.

## Batch E boundary

The Environment/Adversary payloads are faithful Edgeheart mappings, not canonical Cybermancy Fast Play entities.
